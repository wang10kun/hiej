package calc


func Add(a int, b int) int {
	return a + b
}