package main

import(
	a "go_dev/day2/example2/add"
	"fmt"
)


func main() {
	
	fmt.Println("Name=", a.Name)
	fmt.Println("age=", a.Age)
}