select count(*) from  V_HIS_PATS_IN_HOSPITAL t where t.dept_code='032501' and to_char(t.admission_date,'yyyy-mm')=to_char(sysdate, 'yyyy-mm')
