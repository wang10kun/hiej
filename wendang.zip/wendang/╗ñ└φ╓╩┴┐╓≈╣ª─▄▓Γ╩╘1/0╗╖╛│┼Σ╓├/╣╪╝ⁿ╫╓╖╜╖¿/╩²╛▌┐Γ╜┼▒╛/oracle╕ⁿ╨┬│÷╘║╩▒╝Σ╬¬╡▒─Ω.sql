--ɾ���ظ�����
DELETE from V_HIS_PATS_DISCHARGE t WHERE (t.patient_id) IN (
SELECT s.patient_id FROM V_HIS_PATS_DISCHARGE s GROUP BY s.patient_id HAVING COUNT(s.patient_id) > 1) 
AND ROWID NOT IN (SELECT MIN(ROWID) FROM V_HIS_PATS_DISCHARGE k GROUP BY k.patient_id HAVING COUNT(*) > 1);
--ɾ��2��29������
DELETE FROM V_HIS_PATS_DISCHARGE a where to_char(a.admission_date,'mm-dd')='02-29' 
or  to_char(a.leave_time,'mm-dd')='02-29';
--���¹ǿƲ�����Ժ������Ժʱ��Ϊ����
update V_HIS_PATS_DISCHARGE t set t.admission_date=
(select to_date(to_char(sysdate, 'yyyy') || to_char(k.admission_date, '/mm/dd hh24:mi:ss'), 'yyyy/mm/dd hh24:mi:ss') 
from V_HIS_PATS_DISCHARGE k where k.patient_id=t.patient_id) 
where t.dept_code='032501' and t.admission_date<
to_date(to_char(sysdate, 'yyyy') || '/01/01','yyyy/mm/dd');
--���¹ǿƲ�����Ժ���˳�Ժʱ��Ϊ����
update V_HIS_PATS_DISCHARGE t set t.leave_time=
(select to_date(to_char(sysdate, 'yyyy') || to_char(k.leave_time, '/mm/dd hh24:mi:ss'), 'yyyy/mm/dd hh24:mi:ss') 
from V_HIS_PATS_DISCHARGE k where k.patient_id=t.patient_id)
where t.dept_code='032501' and t.leave_time<
to_date(to_char(sysdate, 'yyyy') || '/01/01','yyyy/mm/dd')
