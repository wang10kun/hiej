select count(*) from  V_HIS_PATS_DISCHARGE t where t.dept_code='032501' and to_char(t.leave_time,'yyyy-mm')=to_char(sysdate, 'yyyy-mm')
